import React, { Component } from 'react';

import axios from 'axios';
class Signup extends Component {
  initialState = {
    firstName: '',
    password: '',
    lastName: '',
    email: '',
    edit:false,
    id:null
  }
  constructor(props) {
    super(props);
    this.state = {
      ...this.initialState,
      responseData: []
    }
  }
  _onedit = (e, ele) => {
  
    const { firstName, lastName, email, password } = ele;
    this.setState({ firstName, lastName, email, password,edit:true,id:ele.id })
  }
  _onSubmit = (e) => {
    e.preventDefault();
    const { firstName, password, lastName, email } = this.state;
    console.log(firstName, password, lastName, email);
    if(firstName&&password &&lastName&&email)
    if(!this.state.edit){
    axios.post('http://localhost:3005/api/meets', { firstName, password, lastName, email }).then(res => {
      this.getData();
      
    
    
      this.setState({ ...this.initialState })
      this.props.history.push('/table')
    }).catch(err => console.log(err))
  }
  else{
    axios.patch(`http://localhost:3005/api/meets/${this.state.id}`,{firstName, lastName, email, password})
    .then(res=>{
        if(res.status>=200 && res.status<=299){
        this.setState({...this.initialState})
        this.getData();
      }
    })
    .catch(err=>alert(JSON.stringify(err)))  
  }
  }
  onDelete=(ele)=>{
    axios.delete(`http://localhost:3005/api/meets/${ele.id}`)
    .then(res=>{if(res.status >=200&&res.status<299)
    alert("deleted successfully")
    this.getData();
})
  .catch(err=>err)
    }

  // get users data
  getData() {
    axios.get('http://localhost:3005/api/meets').then(res => {
      console.log(res)
      this.setState({
        responseData: res.data
      })
    }).catch(err => err)
  }

  componentDidMount() {
    this.getData();
  }
   render() {
    return (
      <div>
        <div className="form">
          <form name="contactform" className="contactName" >
            firstName :<input type="text" name="firstName" className="form-control" value={this.state.firstName} placeholder="Enter firstName" onChange={e => this.setState({ firstName: e.target.value })} /><br />
            lastName: <input type="text" className="form-control" name="lastName" value={this.state.lastName} placeholder="Enter lastName" onChange={e => this.setState({ lastName: e.target.value })} />
         <br />
            Password:<input type="password" name="password" className="form-control" value={this.state.password} placeholder="enter password" onChange={e => this.setState({ password: e.target.value })} /><br />
            email:<input type="text" name="email" className="form-control" value={this.state.email} placeholder="enter email" onChange={e => this.setState({ email: e.target.value })} /><br />
            <div className="row">
              <div className="col-2" style={{'margin':20,'padding':20}}>
            <button type="submit" className="btn btn-primary" onClick={(e) => this._onSubmit(e)}>{this.state.edit?'Update':'Submit'}</button>
            
            <button type="reset" className="btn btn-danger" onClick={e=>this.setState({...this.initialState})}>Reset</button>
            </div>
            </div>
          </form>
        </div>
   </div>
    )}}
export default Signup;