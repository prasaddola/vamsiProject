import React from 'react';
import Home from './Home';
import Signup from './Signup';
import Table from './Table';
import {Route,Link, BrowserRouter as Router,Switch} from 'react-router-dom';
import logo from './logo.svg';
import './App.css';
const headerStyle={
  display: 'inline-block',
  width: '100%',
  height: 'auto',
  backgroundColor:'black',
}
function App() {
  return (
    <div className="App">
      
       <Router>
<div >
<header>
<ul>
<li><Link to="/home">home</Link></li>
<li><Link to="/Signup">signup</Link></li>
<li><Link to="/Table">table</Link></li>
</ul>
</header>
</div>
<Switch>
<Route exact path="/home"  component={Home}/>
<Route path="/signup" component={Signup}/>
<Route path="/table" component={Table}/>
</Switch>
</Router> 
 </div>
  );
}export default App;
