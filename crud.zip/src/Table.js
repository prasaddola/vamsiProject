import React,{Component } from 'react';
import axios from 'axios';

class Table extends Component{
    constructor(){
        super();
        this.state=""
    }
    _onedit = (e, ele) => {
  
      const { firstName, lastName, email, password } = ele;
      this.setState({ firstName, lastName, email, password,edit:true,id:ele.id })
      this.props.history.push('/signup')
    }
    onDelete=(e,ele)=>{
      axios.delete(`http://localhost:3005/api/meets/${ele.id}`)
      .then(res=>{if(res.status >=200&&res.status<299)
      alert("deleted successfully")
      this.getData();
  })
    .catch(err=>err)
      }
    getData(){
      axios.get('http://localhost:3005/api/meets').then(res => {
        console.log(res)
        this.setState({
          responseData: res.data
        })
      }).catch(err => err)
    
    }
    componentWillMount(){
      this.getData();
    }
    render(){
        return(
            <div>
                <div>
            <table className="table table-dark">
            <thead>
              <tr>
                <th scope="col">firstName</th>
                <th scope="col">lastName</th>
                <th scope="col">password</th>
                <th scope="col">email</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {this.state.responseData && this.state.responseData.map((ele, index) => {
                return (<tr key={index + 1}>

                  <td>{ele.firstName}</td>
                  <td>{ele.lastName}</td>
                  <td>{ele.password}</td>
                  <td>{ele.email}</td>
                  <td><button type="button" className="btn btn-secondary" onClick={(e) => this._onedit(e, ele)}>edit</button></td>
                  <td><button type="button" className="btn btn-danger" onClick={(e)=>this.onDelete(e,ele)}>Delete</button></td>
                </tr>
                )
              })}
            </tbody>

          </table>
        </div>
            </div>
        )
    }
}
export default Table;